import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'picdance · 木都繪舞',description:'畫一個你，讓想像在嘉義木都跳舞。'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="zh-Hant"><body>{children}</body></html>}
