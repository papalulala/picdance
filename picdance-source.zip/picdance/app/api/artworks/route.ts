import { env } from 'cloudflare:workers';
const headers = { 'Cache-Control':'no-store' };
function roomOf(request:Request){const r=new URL(request.url).searchParams.get('room')||'chiayi';return /^[a-zA-Z0-9_-]{1,32}$/.test(r)?r:null;}
export async function GET(request:Request){
 const room=roomOf(request);if(!room)return Response.json({error:'房間代碼格式不正確'},{status:400});
 try{const now=Date.now();const result=await env.DB!.prepare('SELECT id,image,created_at AS createdAt,seq FROM artworks WHERE room=? AND created_at>? ORDER BY seq DESC LIMIT 30').bind(room,now-60000).all();
 return Response.json({artworks:result.results.reverse(),serverTime:now},{headers});}catch{return Response.json({error:'暫時無法連接共同場景，請稍後再試。'},{status:503,headers});}
}
export async function POST(request:Request){
 const room=roomOf(request);if(!room)return Response.json({error:'房間代碼格式不正確'},{status:400});
 if(request.headers.get('origin') && request.headers.get('origin')!==new URL(request.url).origin)return Response.json({error:'不允許的來源'},{status:403});
 if(Number(request.headers.get('content-length')||0)>140000)return Response.json({error:'作品太大，請簡化後再送出。'},{status:413});
 try{
 const raw=await request.text();if(raw.length>140000)return Response.json({error:'作品太大。'},{status:413});
 const {id,image}=JSON.parse(raw);if(typeof id!=='string'||!/^[a-f0-9-]{36}$/.test(id)||typeof image!=='string'||!/^data:image\/png;base64,iVBORw0KGgo[A-Za-z0-9+/=]+$/.test(image)||image.length>130000)return Response.json({error:'作品格式不正確，請重新送出。'},{status:400});
 const now=Date.now();
 await env.DB!.batch([
 env.DB!.prepare('DELETE FROM artworks WHERE created_at<=?').bind(now-60000),
 env.DB!.prepare('INSERT OR IGNORE INTO artworks (id,room,image,created_at) VALUES (?,?,?,?)').bind(id,room,image,now),
 env.DB!.prepare('DELETE FROM artworks WHERE room=? AND seq NOT IN (SELECT seq FROM artworks WHERE room=? ORDER BY seq DESC LIMIT 30)').bind(room,room)
 ]);
 return GET(request);
 }catch{return Response.json({error:'送出失敗，畫作已保留，請再試一次。'},{status:503,headers});}
}

