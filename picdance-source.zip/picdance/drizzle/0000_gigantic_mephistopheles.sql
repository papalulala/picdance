CREATE TABLE `artworks` (
	`seq` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`id` text NOT NULL,
	`room` text NOT NULL,
	`image` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `artworks_id_unique` ON `artworks` (`id`);