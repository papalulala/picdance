import { sqliteTable, integer, text } from 'drizzle-orm/sqlite-core';
export const artworks = sqliteTable('artworks', {
 seq: integer('seq').primaryKey({ autoIncrement: true }),
 id: text('id').notNull().unique(),
 room: text('room').notNull(),
 image: text('image').notNull(),
 createdAt: integer('created_at').notNull(),
});
